﻿using Microsoft.AspNetCore.SignalR;

namespace MessengerServer.Hubs;

public class ChatHub : Hub
{
    public async Task SendPrivate(string from, string to, string message)
    {
        await Clients.User(to)
            .SendAsync("ReceivePrivate", from, message);
    }

    public override async Task OnConnectedAsync()
    {
        var login = Context.GetHttpContext()?.Request.Query["login"];
        if (!string.IsNullOrEmpty(login))
        {
            Context.Items["login"] = login;
        }

        await base.OnConnectedAsync();
    }

    public override async Task OnDisconnectedAsync(Exception? exception)
    {
        await base.OnDisconnectedAsync(exception);
    }
}
