﻿using MessengerServer.Data;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/users")]
public class UsersController : ControllerBase
{
    private readonly AppDbContext _db;

    public UsersController(AppDbContext db)
    {
        _db = db;
    }

    [HttpGet("search")]
    public IActionResult Search(string query)
    {
        if (string.IsNullOrWhiteSpace(query))
            return Ok(new List<object>());

        var users = _db.Users
            .Where(u => u.Login.Contains(query))
            .Select(u => new { u.Id, u.Login })
            .ToList();

        return Ok(users);
    }
}
