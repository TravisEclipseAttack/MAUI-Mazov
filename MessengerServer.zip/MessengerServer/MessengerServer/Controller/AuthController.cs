﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MessengerServer.Data;
using MessengerServer.Models;

namespace MessengerServer.Controllers;

[Route("api/[controller]")]
[ApiController]
public class AuthController : ControllerBase
{
    private readonly AppDbContext _context;

    public AuthController(AppDbContext context)
    {
        _context = context;
    }

    // 🔹 Регистрация
    [HttpPost("register")]
    public async Task<ActionResult> Register([FromBody] AuthUser user)
    {
        if (await _context.Users.AnyAsync(u => u.Login == user.Login))
            return BadRequest("Пользователь уже существует");

        _context.Users.Add(new User
        {
            Login = user.Login,
            Password = user.Password
        });

        await _context.SaveChangesAsync();
        return Ok();
    }

    // 🔹 Логин
    [HttpPost("login")]
    public async Task<ActionResult<AuthUser>> Login([FromBody] AuthUser user)
    {
        var dbUser = await _context.Users
            .FirstOrDefaultAsync(u => u.Login == user.Login && u.Password == user.Password);

        if (dbUser == null)
            return BadRequest("Неверный логин или пароль");

        return Ok(new AuthUser
        {
            Login = dbUser.Login,
            Password = dbUser.Password
        });
    }

    // 🔹 Получение всех пользователей
    [HttpGet("users")]
    public async Task<ActionResult<List<string>>> GetUsers()
    {
        var users = await _context.Users
            .Select(u => u.Login)
            .ToListAsync();

        return Ok(users);
    }


}
